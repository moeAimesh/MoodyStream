"""Aufgabe: Kleine, generische Dialoge (Prompt/Alert/Confirm).

Nutzung: von Setup & Live-GUI."""