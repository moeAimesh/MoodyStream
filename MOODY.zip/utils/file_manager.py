"""Aufgabe: Downloads (mit Timeout/Retry), Pfade, Existenz prüfen, „sanitize filename“.

API:

def download_to_cache(url:str, cache_dir:str) -> str  # returns relative path"""