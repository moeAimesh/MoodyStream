"""Aufgabe: Live-Overlay (kleines Panel):

„Erkannt: thumbsup → spiele ok.mp3“

FPS, CPU/GPU-Auslastung auch zeigen maybe."""