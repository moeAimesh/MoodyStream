"""Aufgabe: Fenster mit Tabs: Setup, Live, Einstellungen.

Eingaben: Events aus Kamera/Audio.

Ausgaben: visuelles Feedback, Buttons („Setup erneut starten“, „Profil wechseln“).

Tipp: GUI in eigenem Thread oder async."""