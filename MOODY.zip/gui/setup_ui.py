"""Aufgabe: Schrittweises Setup:

Schritt 1: Profilname,

Schritt 2: Gesichts-Baseline (Fortschritt, Mini-Preview),

Schritt 3: Sound-Zuordnung (öffnet Webview, zeigt gespeicherte Sounds).

Ausgaben: Speichert Profil."""