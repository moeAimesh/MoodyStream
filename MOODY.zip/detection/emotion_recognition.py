"""Aufgabe: Aus Emotions-Scores eine diskrete Emotion ableiten (mit Schwellenwerten, Hysterese, Mehrframe-Mehrheit).

Eingaben: Scores von face_analyzer.

Ausgaben: z. B. "laugh", "angry" oder None.

Ziel: Stabile Entscheidungen, nicht bei jedem Frame springen."""