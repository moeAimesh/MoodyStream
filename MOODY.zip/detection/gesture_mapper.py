"""Aufgabe: Gesten-Label → Sound-Key (z. B. "thumbsup" → "ok").

Eingaben: Geste, Profil-Mapping (frei definierbar).

Ausgaben: Sound-Key oder None."""