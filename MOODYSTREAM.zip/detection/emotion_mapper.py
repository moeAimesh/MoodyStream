"""Aufgabe: aus emotion_recognition.py erkannte Emotion fangen → passende Sound-Key spielen (z.B. "happy" → "laugh").

Eingaben: Emotion, Profil-Mapping.

Ausgaben: Sound-Key oder None.



possible API:
def map_emotion_to_sound(emotion: str, profile: dict) -> Optional[str]:
    return "laugh"  #Beispiel """