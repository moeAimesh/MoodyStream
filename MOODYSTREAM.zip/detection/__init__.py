"""Detection package initialization."""
from utils.mediapipe_fix import apply_fix

# Apply MediaPipe fix before any MediaPipe imports
apply_fix()
