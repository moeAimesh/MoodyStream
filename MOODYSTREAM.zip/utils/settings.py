"""Aufgabe: Zentrale Pfade/Konstanten:

BASE = Path(__file__).resolve().parents[1]
CACHE = BASE/"sounds"/"sound_cache"
PROFILES = BASE/"setup"/"profiles"


Nutzen: überall identische Pfade, kein Copy-Paste."""